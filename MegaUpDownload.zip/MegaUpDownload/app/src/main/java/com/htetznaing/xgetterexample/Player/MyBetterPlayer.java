package com.htetznaing.xgetterexample.Player;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.halilibo.bvpkotlin.BetterVideoPlayer;
import com.htetznaing.xgetterexample.R;

public class MyBetterPlayer extends AppCompatActivity {
    BetterVideoPlayer videoPlayer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_better_player);

        videoPlayer = findViewById(R.id.player);
        videoPlayer.setSource(Uri.parse("https://scontent-lga3-1.xx.fbcdn.net/v/t39.24130-6/56230606_2329729830589895_6939588670355943658_n.mp4?_nc_cat=100&efg=eyJxZV9ncm91cHMiOlsidW5tdXRlZCJdLCJ2ZW5jb2RlX3RhZyI6Im9lcF9oZCJ9&_nc_ht=scontent-lga3-1.xx&oh=f92500c61a51e6a28aa5e25c0cb320f1&oe=5D3D1980"));

    }

    @Override
    protected void onPause() {
        super.onPause();
        videoPlayer.pause();
    }
}
