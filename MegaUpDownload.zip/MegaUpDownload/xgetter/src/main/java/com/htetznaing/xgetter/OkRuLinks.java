package com.htetznaing.xgetter;

public class OkRuLinks {
    String url;
    String mobile144px;
    String lowest240px;
    String low360px;
    String sd480px;
    String HD;
    String FullHD;
    String quad2K;
    String ultra4K;

    public String getUrl() {
        return url;
    }

    public String getMobile144px() {
        return mobile144px;
    }

    public String getLowest240px() {
        return lowest240px;
    }

    public String getLow360px() {
        return low360px;
    }

    public String getSd480px() {
        return sd480px;
    }

    public String getHD() {
        return HD;
    }

    public String getFullHD() {
        return FullHD;
    }

    public String getQuad2K() {
        return quad2K;
    }

    public String getUltra4K() {
        return ultra4K;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public void setMobile144px(String mobile144px) {
        this.mobile144px = mobile144px;
    }

    public void setLowest240px(String lowest240px) {
        this.lowest240px = lowest240px;
    }

    public void setLow360px(String low360px) {
        this.low360px = low360px;
    }

    public void setSd480px(String sd480px) {
        this.sd480px = sd480px;
    }

    public void setHD(String HD) {
        this.HD = HD;
    }

    public void setFullHD(String fullHD) {
        FullHD = fullHD;
    }

    public void setQuad2K(String quad2K) {
        this.quad2K = quad2K;
    }

    public void setUltra4K(String ultra4K) {
        this.ultra4K = ultra4K;
    }
}
