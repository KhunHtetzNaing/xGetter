package com.htetznaing.xgetter;

public class VkLinks {
    String url240,url360,url480,url720,url1080;

    public String getUrl240() {
        return url240;
    }

    public void setUrl240(String url240) {
        this.url240 = url240;
    }

    public String getUrl360() {
        return url360;
    }

    public void setUrl360(String url360) {
        this.url360 = url360;
    }

    public String getUrl480() {
        return url480;
    }

    public void setUrl480(String url480) {
        this.url480 = url480;
    }

    public String getUrl720() {
        return url720;
    }

    public void setUrl720(String url720) {
        this.url720 = url720;
    }

    public String getUrl1080() {
        return url1080;
    }

    public void setUrl1080(String url1080) {
        this.url1080 = url1080;
    }
}
